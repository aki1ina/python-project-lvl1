#!/usr/bin/env python
import random
import brain_games.scripts.brain_game

def brain_even():
    brain-games
    print(Answer "yes" if the number is even, otherwise answer "no".)
    i=1
    n=0
    while i <= 3:
        number = random.randrange(0, 100, 1)
        print('Question: ' + number)
        answer = prompt.string(Your answer: )
        if (number % 2 = 0 and answer = 'yes') or (number % 2 <> 0 and answer = 'no'):
            print('Correct!')
        else:
            n = n + 1
    if n = 0:
        print('Congratulations, ' + name +'!')