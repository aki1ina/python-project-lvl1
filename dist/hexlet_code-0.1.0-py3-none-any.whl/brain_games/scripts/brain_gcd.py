#!/usr/bin/env python
from brain_games.games import gcd
from brain_games.game_template import template


def main():
    template(gcd)


if __name__ == '__main__':
    main()
